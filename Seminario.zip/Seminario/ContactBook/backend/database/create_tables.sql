CREATE DATABASE IF NOT EXISTS contract_book;
USE contract_book;

-- Tabla 'contacto' --
CREATE TABLE IF NOT EXISTS contact  (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstname STRING (255) NOT NULL,
    lastname STRING(255) NOT NULL,
    telephone STRING (20) NOT NULL
    address STRING (255) NOT NULL
);

-- Tabla 'telefono' --
CREATE TABLE IF NOT EXISTS telephone(
    id INT AUTO_INCREMENT PRIMARY KEY,
    telephone STRING (255) NOT NULL,
    areacode STRING(255) NOT NULL,
    prefix STRING (20) NOT NULL
);


-- Tabla intermedia 'contacto_tel' --
CREATE TABLE IF NOT EXISTS contact_tel (
    id_contact INT,
    id_telephone INT,
    FOREIGN KEY (id_contact) REFERENCES contact(id),
    FOREIGN KEY (id_telephone) REFERENCES telephonr(id),
    PRIMARY KEY (id_contact, id_telephone)
);


-- CRUD para tabla 'contact' --
-- Create
INSERT INTO contact (firstname, lastname, telephone, address) VALUES ('Raton', 'Perez', '1234567890', 'Dirección');

-- Read (All)
SELECT * FROM contact;

-- Update
UPDATE contact SET firstname = 'NuevoNombre' WHERE id = 1;

-- Delete
DELETE FROM contact WHERE id = 1;


--  CRUD para tabla 'telephone' --
-- Create
INSERT INTO telephone (telephone, areacode, prefix) VALUES ('1234567890', '123', '456');

-- Read (All)
SELECT * FROM telephone;

-- Update
UPDATE telephone SET telephone = '0987654321' WHERE id = 1;

-- Delete
DELETE FROM telephone WHERE id = 1;

--  CRUD para tabla intermedia 'contact_tel' --
-- Create
INSERT INTO contact_tel (id_contact, id_telephone) VALUES (1, 1);

-- Read (All)
SELECT * FROM contact_tel;

-- Delete (Borrar)
DELETE FROM contact_tel WHERE id_contact = 1 AND id_telephone = 1;